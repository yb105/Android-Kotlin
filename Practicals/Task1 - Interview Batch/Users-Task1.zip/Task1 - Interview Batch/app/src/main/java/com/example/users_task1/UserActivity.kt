package com.example.users_task1

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import com.example.users_task1.databinding.ActivityUserBinding
import java.io.Serializable
import java.util.*
import kotlin.collections.ArrayList

class UserActivity : AppCompatActivity() {
    lateinit private var binding:ActivityUserBinding
    var userList:ArrayList<UserData> = ArrayList()

    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        var sharedPreferences = this.getSharedPreferences("get_id",Context.MODE_PRIVATE)
        var editor = sharedPreferences.edit()
        var id = 0
        id = sharedPreferences.getInt("id",0)
        id = id +1



        editor.putInt("id",id)
        editor.apply()
        editor.commit()



        var gender = ""


        Log.d("id@@","$id")


        binding.txtDob.setOnClickListener {
            var calendar = Calendar.getInstance()

            var d = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { datePicker, i, i2, i3 ->
                var mon = 1 + i2
                binding.txtDob.setText("$i3 - $mon - $i")

            },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH))

            d.show()

        }

        binding.radioGroup.setOnCheckedChangeListener{group,checkedId ->
            if (checkedId == R.id.radioMale){
                gender = "male"
            }else if(checkedId == R.id.radioFemale){
                gender = "female"
            }
        }
        binding.btnUser.setOnClickListener {



            var name = binding.edName.text.toString()
            var email = binding.edEmail.text.toString()
            var dob = binding.txtDob.text.toString()
            var contact = binding.edContact.text.toString()
            var age = binding.edAge.text.toString()

             var userData = UserData(id,name,email,age,dob,contact,gender)

            userList.add(userData)



          var intent = Intent(this@UserActivity,MainActivity::class.java)

            intent.putExtra("name",name)
            intent.putExtra("email",email)
            intent.putExtra("dob",dob)
            intent.putExtra("contact",contact)
            intent.putExtra("age",age)
            intent.putExtra("id",id)
            intent.putExtra("gender",gender)

            startActivity(intent)


        }


    }



}