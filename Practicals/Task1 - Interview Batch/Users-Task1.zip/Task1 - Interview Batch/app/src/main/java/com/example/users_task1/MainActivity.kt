package com.example.users_task1

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type


class MainActivity : AppCompatActivity() {

    lateinit var recyclerView: RecyclerView
    lateinit var fab:FloatingActionButton
    var arrayList:ArrayList<UserData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        fab = findViewById(R.id.floatingActionButton)

         loadData()
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = UserAdapter(this,getIntentExtras())


        fab.setOnClickListener {
            startActivity(Intent(this@MainActivity,UserActivity::class.java))
        }
    }





    private fun getIntentExtras():ArrayList<UserData>{



        var name = intent.getStringExtra("name")
        var email = intent.getStringExtra("name")
        var age = intent.getStringExtra("age")
        var gender = intent.getStringExtra("gender")
        var contact = intent.getStringExtra("contact")
        var dob = intent.getStringExtra("dob")
        var id = intent.getIntExtra("id",0)

        if (name != null){
            arrayList.add(UserData(id,name,email,age,dob,contact,gender))
            savedata()

        }
        updateIntentExtras()

        return arrayList

    }

    private fun updateIntentExtras(){

        var name = intent.getStringExtra("name1")
        var email = intent.getStringExtra("name1")
        var age = intent.getStringExtra("age1")
        var gender = intent.getStringExtra("gender1")
        var contact = intent.getStringExtra("contact1")
        var dob = intent.getStringExtra("dob1")
        var id = intent.getIntExtra("id1",0)
        var postion = intent.getIntExtra("postion1",0)

        if (name != null){
            arrayList.set(postion,UserData(id,name,email,age,dob,contact,gender))
            savedata()


        }
    }


    fun savedata(){

        var sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
       var editor = sharedPreferences.edit();
        var gson =  Gson();
        var json = gson.toJson(arrayList);
        editor.putString("arrayList", json);
        editor.apply();
        Toast.makeText(this, "Saved Array List to Shared preferences. ", Toast.LENGTH_SHORT).show();
    }

    fun loadData(){

        var sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        var gson =  Gson();

        var json = sharedPreferences.getString("arrayList","")

        val type: Type = object : TypeToken<ArrayList<UserData?>?>() {}.type
        arrayList = gson.fromJson(json, type)


    }


}