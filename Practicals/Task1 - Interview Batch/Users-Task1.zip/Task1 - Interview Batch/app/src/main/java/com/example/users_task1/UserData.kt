package com.example.users_task1

import android.os.Parcel
import android.os.Parcelable

data class UserData(
    var id:Int,
    var name: String?,
    var email:String?,
    var age:String?,
    var dob:String?,
    var contact:String?,
    var gender:String?)